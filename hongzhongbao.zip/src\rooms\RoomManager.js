/**
 * RoomManager.js — 房间管理器
 *
 * 功能：创建/加入/离开房间、自动AI补位、游戏生命周期管理
 */

const Player = require('./Player');
const GameState = require('../game/GameState');

class RoomManager {
  constructor() {
    this.rooms = new Map();   // roomId → Room
    this.playerRoom = new Map(); // playerId → roomId
    this.roomIdCounter = 0;
  }

  /** 创建房间 */
  createRoom(hostId, hostName) {
    const roomId = `room_${++this.roomIdCounter}`;
    const room = {
      id: roomId,
      hostId,
      players: [],
      gameState: null,
      status: 'waiting', // waiting | playing
    };
    
    const host = new Player(hostId, hostName, false, 0);
    room.players.push(host);
    this.rooms.set(roomId, room);
    this.playerRoom.set(hostId, roomId);

    return room;
  }

  /** 加入房间 */
  joinRoom(roomId, playerId, playerName) {
    const room = this.rooms.get(roomId);
    if (!room) return { error: '房间不存在' };
    if (room.status === 'playing') return { error: '游戏已经开始' };
    if (room.players.length >= 4) return { error: '房间已满' };
    if (this.playerRoom.has(playerId)) return { error: '你已在其他房间' };

    const isAI = false;
    const seatIndex = room.players.length;
    const player = new Player(playerId, playerName, isAI, seatIndex);
    room.players.push(player);
    this.playerRoom.set(playerId, roomId);

    return { room, player };
  }

  /** 离开房间 */
  leaveRoom(playerId) {
    const roomId = this.playerRoom.get(playerId);
    if (!roomId) return null;

    const room = this.rooms.get(roomId);
    if (!room) return null;

    // 移除玩家
    const idx = room.players.findIndex(p => p.id === playerId);
    if (idx !== -1) {
      room.players.splice(idx, 1);
      // 重新分配座位号
      room.players.forEach((p, i) => p.seatIndex = i);
    }

    this.playerRoom.delete(playerId);

    // 如果房间空了，删除房间
    if (room.players.length === 0) {
      this.rooms.delete(roomId);
      return null;
    }

    return room;
  }

  /** 填充AI到满4人 */
  fillWithAI(roomId) {
    const room = this.rooms.get(roomId);
    if (!room) return null;

    const aiNames = ['AI-小东', 'AI-小南', 'AI-小西', 'AI-小北'];
    
    while (room.players.length < 4) {
      const aiId = `ai_${roomId}_${room.players.length}`;
      const aiName = aiNames[room.players.length] || `AI-${room.players.length}`;
      const seatIndex = room.players.length;
      const aiPlayer = new Player(aiId, aiName, true, seatIndex);
      room.players.push(aiPlayer);
    }

    return room;
  }

  /** 检查玩家是否准备好（所有真人已准备） */
  allHumansReady(roomId) {
    const room = this.rooms.get(roomId);
    if (!room) return false;
    return room.players
      .filter(p => !p.isAI)
      .every(p => p.isReady);
  }

  /** 玩家准备 */
  setReady(playerId) {
    const roomId = this.playerRoom.get(playerId);
    if (!roomId) return false;
    const room = this.rooms.get(roomId);
    if (!room) return false;
    
    const player = room.players.find(p => p.id === playerId);
    if (!player) return false;
    
    player.isReady = true;
    return true;
  }

  /**
   * 开始游戏
   * 1. 补AI到4人
   * 2. 创建GameState
   * 3. 执行定庄
   * 4. 执行起牌
   */
  startGame(roomId) {
    const room = this.rooms.get(roomId);
    if (!room) return { error: '房间不存在' };

    // 补AI
    this.fillWithAI(roomId);

    if (room.players.length !== 4) {
      return { error: '人数不足' };
    }

    room.status = 'playing';

    // 创建游戏状态
    const gameState = new GameState(room.players);
    room.gameState = gameState;

    // 定庄 → 起牌
    const initData = gameState.initialize();

    return { room, gameState, initData };
  }

  /** 获取房间信息（不含敏感数据） */
  getRoomInfo(roomId) {
    const room = this.rooms.get(roomId);
    if (!room) return null;
    return {
      id: room.id,
      hostId: room.hostId,
      status: room.status,
      playerCount: room.players.length,
      players: room.players.map(p => ({
        id: p.id,
        name: p.name,
        isAI: p.isAI,
        seatIndex: p.seatIndex,
        isReady: p.isReady,
      })),
    };
  }

  /** 获取玩家所在的房间 */
  getPlayerRoom(playerId) {
    const roomId = this.playerRoom.get(playerId);
    if (!roomId) return null;
    return this.rooms.get(roomId);
  }

  /** 获取所有等待中的房间列表 */
  getWaitingRooms() {
    const list = [];
    for (const [id, room] of this.rooms) {
      if (room.status === 'waiting') {
        list.push(this.getRoomInfo(id));
      }
    }
    return list;
  }
}

module.exports = RoomManager;
